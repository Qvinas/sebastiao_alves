USUARIOS
===================
login: admin
senha: admin
Nome: Sebastiao Alves

====================

login: codemaster
senha: codemaster
Nome: Programador Codemaster

====================

Backoffice acessivel através de localhost/sebastiao_alves/backoffice
Backoffice preparado para 1260px