<?php

$base_dados = [
    "dbname" => "sebastiao_alves_bd",
    "host" => "localhost",
    "user" => "root",
    "pass" => "",
]

?>