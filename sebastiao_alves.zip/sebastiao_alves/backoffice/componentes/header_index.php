<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BackOffice - Sebastião Alves</title>

        <link rel="stylesheet" href="../style.css">
        <link rel="stylesheet" href="style_backoffice.css">
        
    </head>

    <body>
        <header>
            <nav>
                <h3>BackOffice - Sebastião ALves</h3>
                <a href="../index.php">Voltar ao Website</a>
            </nav>
        </header>